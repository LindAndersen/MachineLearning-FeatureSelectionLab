import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler, StandardScaler, Normalizer, Binarizer, RobustScaler, LabelEncoder, OrdinalEncoder
from enum import Enum
import seaborn as sns
import matplotlib.pyplot as plt
from functools import wraps
from sklearn.pipeline import Pipeline
from sklearn.metrics import (
accuracy_score, precision_score, recall_score, f1_score,
classification_report, confusion_matrix
)


#region COLORS
class Color(Enum):
    RESET = "\033[0m"
    RED   = "\033[31m"
    GREEN = "\033[32m"
    YELLOW= "\033[33m"
    BLUE  = "\033[34m"
    CYAN  = "\033[36m"
    WHITE = "\033[37m"
#endregion

#region WRAPPERS
def use_self_df(df_adj):
    @wraps(df_adj)
    def _wrapped(self, df: pd.DataFrame | None = None, *args, **kwargs):
        use_self = df is None
        if use_self:
            df = self.df

        result = df_adj(self, df, *args, **kwargs)
        # Normalize return to (new_df, rest_tuple_or_none)
        if isinstance(result, tuple):
            new_df, rest = result[0], result[1:]
        else:
            new_df, rest = result, None

        if use_self:
            self.df = new_df

        return (new_df, *rest) if rest else new_df
    return _wrapped


def adj_self_numerical(df_adj):
    @wraps(df_adj)
    def wrapper(self, *args, **kwargs):
        result = df_adj(self, *args, **kwargs)

        self.update_num_cols()

        return result
    return wrapper




#endregion


class DataPrepper:
#region INITIALIZE
    def __init__(self, name: str | None = None, data_file: str | None = None, target_col: str = None, df: pd.DataFrame | None = None):
        self.set_name = name

        #TODO: optional header names array pass

        if df is not None:
            self.df = df
        elif data_file is not None:
            self.df = pd.read_csv(data_file, header=0, comment="#", low_memory=False)
        else:
            self.df = pd.DataFrame([])

        self.target_col = target_col
        # self.df_final = None

        self.num_cols = None
        self._df_num = None
        self.update_num_cols() #self.df.select_dtypes(include=[np.number]).columns.tolist()

        if self.target_col in self.num_cols:
            self.num_cols.remove(self.target_col)
#endregion

#region INSPECT

    #TODO: add more graphicals

    def inspect(self, df: pd.DataFrame | None = None):
        df = self.df if df is None else df

        print(f"\n{Color.GREEN.value}=== {self.set_name}: SHAPE ==={Color.RESET.value}\n{df.shape}")

        # df_colored = self.__colorize_nans(df)

        print(f"\n{Color.BLUE.value}=== {self.set_name}: HEAD ==={Color.RESET.value}\n{df.head()}")

        print(f"\n{Color.YELLOW.value}=== {self.set_name}: INFO ==={Color.RESET.value}"); df.info()

        # print(f"\n{Color.RED.value}=== {self.set_name}: MISSING ==={Color.RESET.value}\n{df.isna().sum()}")

        print(f"\n{Color.RED.value}=== {self.set_name}: MISSING ==={Color.RESET.value}")
        self.__print_missing(df)

        if self.num_cols:
            df_num = self._df_num     # <-- arbeite auf der coercten Kopie
            # df_num_colored = self.__colorize_nans(df_num[self.num_cols])
            print(f"\n{Color.CYAN.value}=== {self.set_name}: DESCRIBE (numeric) ==={Color.RESET.value}\n{df_num[self.num_cols].describe()}")
        else:
            print(f"\n{Color.CYAN.value}=== {self.set_name}: DESCRIBE === No Numeric Columns Detected.{Color.RESET.value}")
            print(f"Columns: {list(df.columns)}")

    def __print_missing(self, df: pd.DataFrame):
        total = len(df)
        missing = df.isna().sum()

        for col, n_miss in missing.items():
            if n_miss == 0:
                continue
            ratio = n_miss / total
            if ratio > 0.5:
                color = Color.RED.value
            else:
                color = Color.YELLOW.value
            print(f"{color}{col:<15}{n_miss:>5}/{total} ({ratio:.0%}){Color.RESET.value}")

    def inspect_histograms(self, df: pd.DataFrame | None = None, bins: int=20, kde: bool = True):
        df = self.df if df is None else df
        num_cols = df.select_dtypes(include="number").columns

        for col in num_cols:
            plt.figure(figsize=(6, 4))
            sns.histplot(df[col].dropna(), bins=bins, kde=kde, color="steelblue", edgecolor="black")
            # plt.hist(df[col].dropna(), bins=bins, color="steelblue", edgecolor="black")
            plt.title(f"Histogram of {col}")
            plt.xlabel(col)
            plt.ylabel("Frequency")
            plt.tight_layout()
            plt.show()

    def inspect_graphical(self, df: pd.DataFrame | None = None):
        df = self.df if df is None else df
        for col in df.select_dtypes(include=[np.number]):
            sns.histplot(df[col], kde=True)
            plt.title(col)
            plt.show()

    # @use_self_df add self here
    # @staticmethod
    # def inspect_correlation(df: pd.DataFrame | None = None, annotate: bool = True):
    #     # Korrelationen berechnen
    #     plt.figure(figsize=(8,6))
    #     sns.heatmap(df.corr(numeric_only=True), annot=annotate, cmap="coolwarm", fmt=".2f")
    #     plt.title("Correlationmatrix")
    #     plt.show()


    def inspect_correlation(self, df: pd.DataFrame | None = None, annotate: bool = True, categories: list | None = None):
        if df is None:
            if not hasattr(self, "df") or self.df is None:
                raise ValueError("No DataFrame provided and self.df is not set.")
            df = self.df

        # Wenn Spaltenliste übergeben wurde, nur diese verwenden
        if categories is not None:
            missing = [c for c in categories if c not in df.columns]
            if missing:
                raise ValueError(f"Columns not found in DataFrame: {missing}")
            df = df[categories]

        # Plot erstellen
        plt.figure(figsize=(8, 6))
        sns.heatmap(df.corr(numeric_only=True), annot=annotate, cmap="coolwarm", fmt=".2f")
        plt.title("Correlation Matrix")
        plt.show()

    @staticmethod
    def inspect_boxplot(data: pd.DataFrame, x: str, y: str, title: str = "Some cool title", hue: str | None = None):
        if hue is None:
            hue = ""
        sns.boxplot(x=x, y=y, hue=hue, data=data)
        plt.title(title)
        plt.show()

#endregion

#region MISSING
    @use_self_df
    def missing_kill(self, df: pd.DataFrame | None = None, col: str | None = None) -> pd.DataFrame:

        before = len(df)

        if col:
            df = df.dropna(subset=[col]).copy()
        else:
            df = df.dropna().copy()

        after = len(df)

        print(f"{Color.GREEN.value}Removed {before - after} rows containing NaN values in \"{col}\" ({after} remain).{Color.RESET.value}")
        return df

    @use_self_df
    def missing_forceVal(self, df: pd.DataFrame | None = None, col: str | None = None, value=0) -> pd.DataFrame:

        if col:
            n_missing = df[col].isna().sum()
            df[col] = df[col].fillna(value)
        else:
            n_missing = df.isna().sum().sum()
            df = df.fillna(value)

        print(f"{Color.GREEN.value}Replaced {n_missing} NaN values of \"{col}\" with {value}.{Color.RESET.value}")
        return df

    @use_self_df
    def missing_mean(self, df: pd.DataFrame | None = None, col: str | None = None) -> pd.DataFrame:

        if col:
            if df[col].dtype.kind in "biufc":  # nur numerische Spalten
                n_missing = df[col].isna().sum()
                df[col] = df[col].fillna(df[col].mean())
            else:
                print(f"{Color.RED.value}Column '{col}' is not numeric. Skipped.{Color.RESET.value}")
                return df
        else:
            num_cols = df.select_dtypes(include=["number"]).columns
            n_missing = df[num_cols].isna().sum().sum()
            df[num_cols] = df[num_cols].fillna(df[num_cols].mean())

        print(f"{Color.GREEN.value}Replaced {n_missing} numeric NaN values in \"{col}\" with mean {df[col].mean()}.{Color.RESET.value}")
        return df

    @use_self_df
    def missing_median(self, df: pd.DataFrame | None = None, col: str | None = None) -> pd.DataFrame:

        if col:
            if df[col].dtype.kind in "biufc":
                n_missing = df[col].isna().sum()
                df[col] = df[col].fillna(df[col].median())
            else:
                print(f"{Color.RED.value}Column '{col}' is not numeric. Skipped.{Color.RESET.value}")
                return df
        else:
            num_cols = df.select_dtypes(include=["number"]).columns
            n_missing = df[num_cols].isna().sum().sum()
            df[num_cols] = df[num_cols].fillna(df[num_cols].median())

        print(f"{Color.GREEN.value}Replaced {n_missing} numeric NaN values in \"{col}\" with median {df[col].median()}.{Color.RESET.value}")
        return df


#endregion

#region SCALING_FUNCS

    #TODO: add normalizer

    def apply_minMax(self, df: pd.DataFrame | None = None, col: str | None = None, feature_range=(0,1)) -> pd.DataFrame:

        df = self.df if df is None else df

        if not col or col not in df.columns:
            print(f"{Color.RED.value}Invalid or missing column name: {col}{Color.RESET.value}")
            return df

        data = df[[col]].astype(float)

        scaler = MinMaxScaler(feature_range=feature_range)

        scaled = scaler.fit_transform(data)

        df[col] = scaled

        print(f"{Color.GREEN.value}Scaled '{col}' with MinMaxScaler (range={feature_range}){Color.RESET.value}")
        return df

    def apply_standard(self, df: pd.DataFrame | None = None, col: str | None = None) -> pd.DataFrame:

        df = self.df if df is None else df

        if not col or col not in df.columns:
            print(f"{Color.RED.value}Invalid or missing column name: {col}{Color.RESET.value}")
            return df

        data = df[[col]].astype(float)

        scaler = StandardScaler()

        scaled = scaler.fit_transform(data)

        df[col] = scaled

        print(f"{Color.GREEN.value}Scaled '{col}' with StandardScaler{Color.RESET.value}")
        return df

    def apply_robust(self, df: pd.DataFrame | None = None, col: str | None = None, quantile_range=(25.0, 75.0)) -> pd.DataFrame:
        df = self.df if df is None else df

        if not col or col not in df.columns:
            print(f"{Color.RED.value}Invalid or missing column name: {col}{Color.RESET.value}")
            return df

        data = df[[col]].astype(float)

        scaler = RobustScaler(quantile_range=quantile_range)

        scaled = scaler.fit_transform(data)
        df[col] = scaled

        print(f"{Color.GREEN.value}Scaled '{col}' with RobusScaler (quantile_range:{quantile_range}){Color.RESET.value}")
        return df

    def apply_binarize(self, df: pd.DataFrame | None = None, col: str | None = None, threshold=5.0) -> pd.DataFrame:
        df = self.df if df is None else df

        if not col or col not in df.columns:
            print(f"{Color.RED.value}Invalid or missing column name: {col}{Color.RESET.value}")
            return df

        data = df[[col]].astype(float)

        scaler = Binarizer(threshold=threshold)

        scaled = scaler.fit_transform(data)

        df[col] = scaled

        print(f"{Color.GREEN.value}Scaled '{col}' with Binarizer (threshold={threshold}){Color.RESET.value}")
        return df
#endregion

#region ENCODERS


    @use_self_df
    def apply_onehot(self, df: pd.DataFrame | None = None, col: str | None = None) -> pd.DataFrame:

        # use_self = False
        # if df is None:
        #     use_self = True
        #     df = self.df


        if not col or col not in df.columns:
            print(f"{Color.RED.value}Invalid or missing column name: {col}{Color.RESET.value}")
            return df

        encoded = pd.get_dummies(df[col].astype("category"), prefix=col)

        df = pd.concat([df.drop(columns=[col]), encoded], axis=1)
        # print(df)

        # if use_self:
        #     self.df = df

        print(f"{Color.GREEN.value}Applied One-Hot-Encoding on '{col}' && created {len(encoded.columns)} columns{Color.RESET.value}")

        return df

    @adj_self_numerical
    def apply_labelEncoding(self, df: pd.DataFrame | None = None, col: str | None = None) -> pd.DataFrame:
        df = self.df if df is None else df

        if not col or col not in df.columns:
            print(f"{Color.RED.value}Invalid or missing column name: {col}{Color.RESET.value}")
            return df

        le = LabelEncoder()
        df[col] = le.fit_transform(df[col].astype(str))

        print(f"{Color.GREEN.value}Applied Label-Encoding on '{col}' ({len(le.classes_)} unique classes){Color.RESET.value}")
        return df

    @use_self_df
    @adj_self_numerical
    def apply_ordinal(self, df: pd.DataFrame | None = None, col: str | None = None,
                    categories=None, new_col: str | None = None) -> pd.DataFrame:
        if not col or col not in df.columns:
            print(f"{Color.RED.value}Invalid or missing column name: {col}{Color.RESET.value}")
            return df

        if categories is None:
            cats = sorted(df[col].dropna().unique().tolist())
            categories = [cats]
            print(f"{Color.YELLOW.value}No category order specified for '{col}', using {cats}.{Color.RESET.value}")

        oe = OrdinalEncoder(categories=categories)
        encoded = oe.fit_transform(df[[col]]).ravel()  # -> 1D

        new_col = new_col or f"{col}_ord"
        df[new_col] = encoded  # NEUE Spalte statt Überschreiben

        print(f"{Color.GREEN.value}Applied Ordinal-Encoding on '{col}' → '{new_col}' with categories: {categories[0]}{Color.RESET.value}")
        return df

#endregion


#region EVALUATE
    @staticmethod
    def evaluate_importance(pipe: Pipeline, y: pd.DataFrame | None = None, steps: list | None = None):

        if steps is None:
            steps = ["pre", "clf"]

        legend = True
        if y is not None:
            legend = False

        feature_names = pipe.named_steps[steps[0]].get_feature_names_out()

        importances = pipe.named_steps[steps[1]].feature_importances_

        feat_imp = pd.DataFrame({"Feature": feature_names, "Importance": importances})
        feat_imp = feat_imp.sort_values(by="Importance", ascending=False)

        plt.figure(figsize=(10, 6))
        sns.barplot(data=feat_imp.head(15), x="Importance", y="Feature", palette="viridis", hue=y, legend=True)
        plt.title("Top Feature Importances")
        plt.tight_layout()
        plt.show()


    @staticmethod
    def evaluate_confusion(y_test:pd.DataFrame, y_pred:pd.DataFrame):
        plt.figure(figsize=(6, 5))
        cm = confusion_matrix(y_test, y_pred)
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', cbar=False)
        plt.title('Confusion Matrix')
        plt.ylabel('True Label')
        plt.xlabel('Predicted Label')
        plt.show()

    @staticmethod
    def evaluate_relationships(train_set: pd.DataFrame, features: list, hue: str):

        if train_set is None or features is None or hue is None:
            print("No valid input values passed.")

        sns.pairplot(train_set, vars=features, hue=hue)
        plt.show()

#endregion




#region UTIL
    def __colorize_nans(self, df: pd.DataFrame, color=Color.RED.value) -> pd.DataFrame:
        df_colored = df.copy()
        mask = df.isna()
        df_colored = df_colored.astype(str)
        df_colored[mask] = f"{Color.RED.value}Nan{Color.RESET.value}"

        return df_colored


    def update_num_cols(self):
        num_cols = self.df.select_dtypes(include=[np.number]).columns.tolist()
        # print(self.num_cols)
        if not num_cols:
            _df_num = self.df.apply(
                lambda s: pd.to_numeric(s, errors="coerce") if s.dtype == "object" else s
            )
            num_cols = _df_num.select_dtypes(include=[np.number]).columns.tolist()
        else:
            _df_num = self.df

        self.num_cols = num_cols
        self._df_num = _df_num



#endregion


if __name__=="__main__":
    pass